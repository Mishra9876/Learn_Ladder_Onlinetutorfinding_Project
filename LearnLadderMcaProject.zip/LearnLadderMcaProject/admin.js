document.addEventListener("DOMContentLoaded", function() {
    // Change background color dynamically
    document.body.style.backgroundColor = "#6CB4EE";

    // Form submission validation
    document.querySelector('form').addEventListener('submit', function(event) {
        var emailContactNumber = document.getElementById('fname').value;
        var adminPassword = document.getElementById('lname').value;




        function isValidEmailContactNumber(input) {
            // Email validation
            if (input.includes('@')) {
                return true;
            }

            // Contact number validation (consists of digits 0-9)
            if (!isNaN(input) && input.match(/^\d+$/)) {
                return true;
            }

            return false;
        }
        // Email/Contact number validation
        if (!isValidEmailContactNumber(emailContactNumber)) {
            alert('Please enter a valid email or contact number.');
            event.preventDefault();
            return;
        }

        // Password validation
        if (adminPassword.length < 6) {
            alert('Invaid Password! Please enter a valid password');
            event.preventDefault();
            return;
        }

        // If both validations pass, display success alert
        alert('Form submitted successfully!');
    });
});